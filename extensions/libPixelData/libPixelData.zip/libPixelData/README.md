# libPixelData
Image Encoding and Decoding Library
