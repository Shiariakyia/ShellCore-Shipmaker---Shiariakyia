#import <Cocoa/Cocoa.h>

@interface OnlyIntegerValueFormatter : NSNumberFormatter

@end
